#!/bin/sh

export GOOGLE_APPLICATION_CREDENTIALS="cloudcomputing-341517-8964d68172a7.json"
echo 'EXPORTED'
echo 'Running python file'
python3 anlz.py
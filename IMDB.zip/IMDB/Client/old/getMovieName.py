from flask import Flask, render_template, request
from imdb import IMDb
import json
import redis
import pickle
import time
import logging
from fetchMovieId import initRedis
from waiting import wait
from fetchMovieId import getResultFlag


redis = redis.Redis(host= '35.224.68.198',port= '6378')    
initRedis()
logging.warning("Connected with Redis Server")
app = Flask(__name__)

@app.route('/')
def index():
     return render_template('index.html' , value = "")

@app.route('/getMovieName', methods=['POST'])
def getMovieName():
     try:
          # logging.warning("Result flag ",redis.get('movieResultsFlag'))
          ia = IMDb()
          movieName = request.form['movieName']
          movieObj = ia.search_movie(movieName)      
          movieId = movieObj[0].movieID
          #movieObj1 = ia.get_movie(movieId)
          #print(movieId)
          redis.set('movieId',movieId) ##set the movie ID in Redis
          
          ##set the movie ID flag true, this will trigger second service (getMoviewReviews.py)
          redis.set('movieIdFlag','true') 

          # movie = ia.get_movie(movieId)
          # print(movie)
          # cast = movie.get('cast')
          # print(cast)
          # directors =movie.get('director')
          # print(directors)
          # time.sleep(15)
          i = 0
          # while getResultFlag() == False:
          while getResultFlag() == False:
               i=i+1
          category = redis.get('category')
          print(i)
          redis.set('movieResultsFlag','false')
     except:
          logging.warning("ERROR: Session timeout!")
     # flag = getResultFlag()
     # if flag == 1:
     #      category = redis.get('category')
     #      redis.set('movieResultsFlag','false')
     
     return render_template('result.html' , value = category)

if __name__ == '__main__':
    app.run(host = '0.0.0.0', port = 3000)
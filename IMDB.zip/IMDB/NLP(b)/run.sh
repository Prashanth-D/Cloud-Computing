#!/bin/sh

export GOOGLE_APPLICATION_CREDENTIALS="cc-project-348821-fb76001e7ce0.json"
echo 'EXPORTED'
echo 'Running python file'
python3 anlz.py
# Imports the Google Cloud client library
import string
from google.cloud import language_v1
import redis
import pickle
import ast
import os
import logging
from fetchMovieId import getAnalysisFlag

try:
    redis = redis.Redis(host= '35.224.68.198',port= '6378')
    os.system('export GOOGLE_APPLICATION_CREDENTIALS="cc-project-348821-fb76001e7ce0.json"')
    redis.ping()
    logging.warning("Connected with Redis Server")
except (ConnectionRefusedError):
    logging.warning("ERROR: Connecting to Redis Server")
    

def nlp():
    try:
        reviews = pickle.loads(redis.get('movieReviews'))
        i = 0

        # for review in reviews:
        #     i +=1
        #     print(review['content'])
        #     print(i)

        # Instantiates a client
        client = language_v1.LanguageServiceClient()
        lst =[]
        category=""
        # The text to analyze
        i=0
        for review in reviews:
            text = review['content']
            #print(text)
            
            text = text.replace(".", "")
            document = language_v1.Document(
                content=text, type_=language_v1.Document.Type.PLAIN_TEXT
            )

            # Detects the sentiment of the text
            sentiment = client.analyze_sentiment(
                request={"document": document}
            ).document_sentiment
            # print(sentiment.score)
            logging.warning("Score",sentiment.score)
            lst.append(sentiment.score)
            i +=1

        average=sum(lst)/25                                 #Calculating average score of users review
        score=pickle.dumps(average)     
        redis.set('score', score)                           #Storing the average score value in redis db
        logging.warning("Score of movie",average)
        # print("Score of the film %f" %(average))
        if(average==0):                                     #Classifying the users review into 5 categories based on average score
            category="Neutral"
        elif (0 <average <=0.5):
            category="Good Movie"
        elif(average>0.5):
            category="Strongly recommended"
        elif((average>-0.5) and (average<0)):
            category="Bad movie"
        else:
            category="Worst movie"
        
        ## Set movieAnalysisFlag = FALSE to stop NLP() execution
        redis.set('movieAnalysisFlag','false')
        
        ## Set final result in Redis
        logging.warning(category)
        redis.set('category', category)
        # print(category)

        ## Set movieResultsFlag = TRUE, this will trigger results ready condition in getMovieName.py
        redis.set('movieResultsFlag','true')
    except:
        logging.warning("ERROR: Unable to run/analyz NLP")

while(1):
    flag = getAnalysisFlag()
    if flag == 1:
        nlp()
    # else:
    #     print("Waiting...")
